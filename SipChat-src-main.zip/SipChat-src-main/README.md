<h1>SipChat Source Code</h1>
SipChat is finally opensource by @giisspicytea from instagram

feel free to fork this project and use it for your needs 
Please include credits to @giisspicytea as we worked hard to make this project

<h2>Contact</h2>
spice.lilac534@slmail.me <-- email
